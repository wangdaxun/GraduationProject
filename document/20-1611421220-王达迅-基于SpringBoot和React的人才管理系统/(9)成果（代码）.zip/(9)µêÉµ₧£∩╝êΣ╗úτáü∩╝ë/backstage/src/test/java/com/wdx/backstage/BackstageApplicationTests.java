package com.wdx.backstage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackstageApplicationTests {

    @Test
    void contextLoads() {
    }

}
