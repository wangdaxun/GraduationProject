package com.wdx.manager.bean;

import java.util.Date;

public class JobApply {
	private Integer applyId;
	private Job job;
	private Resume resume;
	private Applicant applicant;
	private Date applyDate;
	
	public JobApply() {
		super();
	}

	public JobApply(Job job, Resume resume, Applicant applicant, Date applyDate) {
		super();
		this.job = job;
		this.resume = resume;
		this.applicant = applicant;
		this.applyDate = applyDate;
	}

	public Integer getApplyId() {
		return applyId;
	}

	public void setApplyId(Integer applyId) {
		this.applyId = applyId;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Resume getResume() {
		return resume;
	}

	public void setApplicantId(Resume resume) {
		this.resume = resume;
	}

	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}
	
}
