package com.wdx.controller;

import org.springframework.stereotype.Controller;

@Controller
public class QuickController {

}
